---
t: "Autodestrucción"
st: "En Toneladas"
sd: "Este dashboard puede autodestruirse a gusto."
kpi: "header"
c: "<p><strong>Todas las áreas de esta grilla pueden eliminarse o modificarse</strong> en base a gráficos, tablas y series de tiempo.</p>"
f: "https://www.indec.gob.ar/ftp/cuadros/economia/metodologia_emae_ago_16.pdf"
 
---