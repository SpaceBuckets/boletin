<template>
<div style="position:relative">
<h4 class="chartitle"><strong>MAE</strong>.  <br>Volumen en millones de dólares<br>Frecuencia Mensual </h4>

           <charts-line
            :key="$state.updated"
            :data="chartData"
            :options="chartOptions"
            :height="420"
          />
       </div>
    </section>

  </div>
</template>

<script>

import mae from "../../json/rofex/mae/d.json";
 import maeDates from "../../json/rofex/mae/dates.json";

export default {
  data() {
    return {
      chartData: {
        labels: maeDates,
        datasets: [
          {
            backgroundColor: 'rgba(46,120,210,0)',
            label: "Desestacionalizado",
            data: mae,
                        borderColor: "rgba(46,120,210,0.8)",

            pointRadius: 0,
            borderWidth: 1.5,
          },
           
              
        ],
      },   
      chartOptions: {
        responsive: true,
        maintainAspectRatio: false,
        animation: { duration: 0 },    
        layout: {
          padding: {
            left: 0,
            right: 0,
            top: 0,
            bottom: 0
          }
        },
        scales: {
          xAxes: [{
            type: 'time',
            offset: true,
            position: 'bottom',
            gridLines: {
              color: "#eee", zeroLineColor: '#eee', drawBorder: false, offsetGridLines: false, borderDash: [2, 2],
              color: "#ddd"
            },
            ticks: { fontColor: "#888", fontSize: 13, },
            time: {
              tooltipFormat: 'DD/MM/YY',
              unit: 'year',
            }
          }],
          yAxes: [{
            ticks: { fontColor: "#888",                callback: function(value, index, values) {
                                return '$' +value;
                        }  },
            gridLines: { 
              color: "#eee", 
              lineWidth: 1, 
              drawBorder: false,          
            },
            scaleLabel: {
              display: true,
              labelString: 'Millones de dólares',
              fontColor: "#888"
            },
            position: "right",
          },
          ],
        },
        legend: {
          display: false,
        },
      },      
    };
  },
};
</script>

 