module.exports = (async function() {

  const parsers = require("@parsers");
  const fetch = require('@adobe/node-fetch-retry');
  const xlsx = require('node-xlsx');
  const kpi = "tasa"
 
  var obj = xlsx.parse((await (await fetch('https://www.bcra.gob.ar/Pdfs/PublicacionesEstadisticas/seriese.xls')).arrayBuffer()));
  var objArr = ['tasa','plazo','badlar','pases']
 
  var payload = {}
  for (let i = 0; i < objArr.length; i++) {
    payload[objArr[i]] = []

    for (let e = 0; e < obj[5].data.length; e++) {
      var date = new Date(Date.UTC(0, 0, obj[5].data[e][0]));
      payload[objArr[i]][e] = {}
      if (date != 'Invalid Date') {
        payload[objArr[i]][e].x = date.toISOString().substring(0, 10)
        if (objArr[i] === 'tasa') { 
          payload[objArr[i]][e].y = obj[4].data[e][1] 
          if (payload[objArr[i]][e].y === 's/o') { payload[objArr[i]][e].y = 0 }
        }
        if (objArr[i] === 'badlar') { 
          if (obj[5].data[e][8] ) { payload[objArr[i]][e].y = obj[4].data[e][8] } else { payload[objArr[i]][e].y = 0 }
        }
      }
    }
    payload[objArr[i]] = payload[objArr[i]].filter(element => { if (Object.keys(element).length !== 0) { return true; } return false; });
    console.log(payload[objArr[i]].length)
  }

  for (let i = 0; i < objArr.length; i++) {

    for (let e = 0; e < obj[5].data.length; e++) {
      var date = new Date(Date.UTC(0, 0, obj[5].data[e][0]));
      if (date != 'Invalid Date') {
        var tempCall = obj[5].data[e][9]
        if (!tempCall) { tempCall = '0' }
        if (objArr[i] === 'plazo') { payload[objArr[i]][e].y = tempCall }

        var tempPases = obj[5].data[e][11]
        if (!tempPases) { tempPases = '0' }
        if (objArr[i] === 'pases') { payload[objArr[i]][e].y = tempPases }

      }
    }
  }
 

  var post = {
    kpi,
  t: "Tasas de Interés",
  st: "Tasa de Política Monetaria",
  sd: "La tasa de referencia de la política monetaria es la de Letras de Liquidez (LELIQ). La tasa de política monetaria indica el sesgo de la política que adopta la autoridad monetaria para alcanzar sus metas de inflación.",
/*   "cells": {
    "1267": {
      "area": "1 / 6 / 2 / 7",
      "kpi": "tasa",
      "type": "Kpi",
      "hasChart": true
    },
    "1416": {
      "area": "1 / 1 / 4 / 6",
      "kpi": "tasa",
      "type": "Line",
      "hasChart": true
    },
    "2367": {
      "area": "2 / 6 / 3 / 7",
      "kpi": "tasa",
      "type": "Kpi",
      "hasChart": true
    },
    "3467": {
      "area": "3 / 6 / 4 / 7",
      "kpi": "tasa",
      "type": "Kpi",
      "hasChart": true
    },
    "4715": {
      "area": "4 / 1 / 7 / 5",
      "kpi": "tasasinternacionales",
      "type": "Line",
      "hasChart": true
    },
    "4757": {
      "area": "4 / 5 / 7 / 7",
      "kpi": "tasa",
      "type": "Table",
      "hasChart": true
    }
  }, */
  c: "<p>La tasa de referencia de la política monetaria es la de Letras de Liquidez (LELIQ). La tasa de política monetaria indica el sesgo de la política que adopta la autoridad monetaria para alcanzar sus metas de inflación.</p><p>El BCRA calibrará las tasas de interés de manera de garantizar una mayor disponibilidad de instrumentos de ahorro que permitan a los argentinos obtener rendimientos acordes con la evolución de la inflación y del tipo de cambio, contribuyendo así a estabilizar las expectativas cambiarias, favoreciendo al proceso de desinflación. Dicho reacomodamiento de la estructura de tasas de interés se complementará con la continuidad de aquellas políticas de estímulo focalizado al crédito al sector privado.</p>",
  fd: "Scraped (XLS)",
  fdr: "http://www.bcra.gov.ar/Pdfs/PublicacionesEstadisticas/series.xlsm",
  fu: "BCRA",
  fur: "http://www.bcra.gov.ar/Pdfs/PublicacionesEstadisticas/series.xlsm",
  frec: "Diaria", 
  d: "El Estimador mensual de actividad económica (EMAE) refleja la evolución mensual de la actividad económica del conjunto de los sectores productivos a nivel nacional. Este indicador permite anticipar las tasas de variación del producto interno bruto (PIB) trimestral.",
  max: 100,
  chart: {
    dates:payload.tasa,
    dimensions: [
      {
        label: "Referencia",
        data: payload.tasa,
        color: "#2E78D2", 
      },
      {
        label: "Badlar",
        data: payload.badlar,
        color: "rgba(46,120,210,0.25)", 
        borderWidth: 1,
      },
      {
        label: "Plazo Fijo",
        data: payload.plazo,
        color: "rgba(46,120,210,0.25)", 
        borderWidth: 1,
      },
      {      
        label: "Pases Pasivos (1d)",
        data: payload.pases,
        color: "#7a49a580",
      },
    ]
  }
}

parsers.writeFileSyncRecursive(`./static/data/${kpi}.json`, JSON.stringify(post));


})()

