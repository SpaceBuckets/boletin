---
t: "ICE"
st: "Índice de Condiciones Externas"
sd: "Este indicador busca reflejar el contexto económico internacional que enfrenta el país, a partir de los niveles de liquidez mundial, los precios de las materias primas, la demanda externa y el ciclo económico de Brasil."
kpi: "ice"
capis:
    'interanual':
    - 0
    'desestacionalizada':
    - 0
    'tendencia-ciclo':
    - 1        
c: "<p>Índice mensual que busca reflejar el contexto económico internacional que enfrenta el país, a partir de los niveles de liquidez mundial (medido por la tasa de interés de la FED), los precios de las materias primas (medido por los términos de intercambio), la demanda externa (medido por el volumen del comercio global) y el ciclo económico de Brasil (medido por su producción industrial).</p><p>Las series fueron normalizadas en base al promedio histórico desde 1997 a la actualidad, dándole un valor igual a 5. Desde allí, una serie que indica un valor por encima de 5 (por encima de la media del período) refleja que la situación externa es más favorable, y viceversa. Se presentan dos indicadores, el ICE-estructural donde la base del análisis son los promedios históricos, y el ICE-coyuntural más de corto plazo (de 5 años) para una mejor captura de los cambios recientes.</p>"
f: "https://www.indec.gob.ar/ftp/cuadros/economia/metodologia_emae_ago_16.pdf"
d: "El Estimador mensual de actividad económica (EMAE) refleja la evolución mensual de la actividad económica del conjunto de los sectores productivos a nivel nacional. Este indicador permite anticipar las tasas de variación del producto interno bruto (PIB) trimestral."
max: 10
cat: "Otros"

---