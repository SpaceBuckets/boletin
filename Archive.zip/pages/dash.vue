<template>
  <div>
        <div class="container-grid" :key="updated">

        <div class="headbert" style="grid-area: 1 / 1 / 2 / 4;">
      <div>
        <div>
          
      <h1>Tachame la Macro</h1>
      <p><em>Febo asoma; ya sus rayos, iluminan el histórico contexto.</em> Esta colección de indicadores intenta develar de donde viene y hacia donde va la siempre entretenida macroeconomía de la República Argentina. Se incluyen <strong>45 KPI</strong> sobre Actividad Económica, Cuentas Nacionales, Politica Monetaria, Precios y Salarios.</p>
      <button>Reportar Bug</button>
      <button>Get Dashboard URL</button>

        </div>
 
<!--         <div class="capis">
          <div>
            <div>Población</div>
            <h3>47.3M</h3>
            <div>Censo 2022</div>
          </div>

          <div>
            <div>PBI per capita</div>
            <h3>$1,015M</h3>
            <div>Dato 2020</div>
          </div>

          <div>
            <div>HDI</div>
            <h3>0.845</h3>
            <div>Dato 2020</div>
          </div>
          <div>
            <div>GINI</div>
            <h3>42.9</h3>
            <div>Dato 2020</div>
          </div>
        </div> -->
      </div>
    </div>
      <div
        @pointerdown="startDrag($event)"
        @pointerup="endDrag($event)"
        @mousemove="hoverling($event)"
        v-for="cells in 36"
        :data-row-start="Math.ceil(cells / 6)"
        :data-row-end="Math.ceil(cells / 6) + 1"
        :data-col-start="getColStart(cells)"
        :data-col-end="getColStart(cells) + 1"
        :key="`cells-${cells}`"
        class="singleCell"
      ></div>
      <div ref="selecter" class="selecter-cell"></div>
      <section
        v-for="item in savedCells"
        :ref="`${item.rowStart}${item.rowEnd}${item.colStart}${item.colEnd}`"
        :style="{ 'grid-row-start': item.rowStart, 'grid-row-end': item.rowEnd,'grid-column-start': item.colStart,'grid-column-end': item.colEnd,}"
        :key="item.id"

      >
        <button class="delete" @click="removeSavedCell(`${item.rowStart}${item.rowEnd}${item.colStart}${item.colEnd}`)">
          <svg fill='none' stroke='#ccc' stroke-width='12' stroke-dashoffset='0' stroke-dasharray='0' stroke-linecap='round' stroke-linejoin='round' xmlns='http://www.w3.org/2000/svg' viewBox='0 0 100 100'><line x1="15" y1="15" x2="85" y2="85" /> <line x1="85" y1="15" x2="15" y2="85" /></svg>
        </button>
        <div class="seleccionador" v-if="!item.height">
          <div class="wrapper">
           <label for="">Chart</label>
          <select @change="setType($event, `${item.rowStart}${item.rowEnd}${item.colStart}${item.colEnd}`)" name="k4pis" id="ca3rs">
            <option value="Line">Line</option>
            <option value="Bar">Bar</option>
            <option value="Kpi">KPI</option>
           </select>   
          <label for="">KPI</label>
          <select @change="setKpi($event, `${item.rowStart}${item.rowEnd}${item.colStart}${item.colEnd}`)" name="kpis" id="cars">
            <option value="emae">EMAE</option>
            <option value="isac">ISAC</option>
            <option value="ipi">IPI</option>
            <option value="ucii">UCII</option>
            <option value="deficit">Deficil Fiscal</option>
            <option value="balanza">Balanza Comercial</option>
            <option value="subsidios">Subsidios Economicos</option>
            <option value="desempleo">Desempleo</option>
            <option value="embi">Riesgo Pais</option>
            <option value="tasa">Tasas de Interes</option>                        
            <option value="ipc">Inflacion</option>                        
            <option value="reservas">Reservas Internacionales</option>                        
            <option value="cambio">Cambio USD/Peso</option>      
            <option value="acero">Produccion de Acero</option>
            <option value="acero">Produccion de Gas</option>
            <option value="acero">Produccion de Petroleo</option>
            <option value="cereales">Produccion de Cereales</option>                              
          </select>
          <div>
          <button>Random</button>

          <button @click="saveChart($event,`${item.rowStart}${item.rowEnd}${item.colStart}${item.colEnd}`)">Submit</button>
          </div>

          </div>

        </div>

        <component v-if="item.height" title="" :is="`charts-generic${item.type}`" :chartHeight="item.height" :data="item.kpi"/>
 
       </section>
    </div>
  </div>
</template>

<script>
export default {
  name: "Dash",
  data() {
    return {
      dragging: false,
      startX: "",
      startY: "",
      savedCells: [
    {
        "rowStart": "2",
        "rowEnd": "4",
        "colStart": "1",
        "colEnd": "4",
        "kpi": "emae",
        "type": "Line",
        "id": "2414",
        "height": 330
    },
    {
        "rowStart": "1",
        "rowEnd": "2",
        "colStart": "4",
        "colEnd": "5",
        "kpi": "emae",
        "type": "Kpi",
        "id": "1245",
        "height": 120
    },
    {
        "rowStart": "2",
        "rowEnd": "4",
        "colStart": "4",
        "colEnd": "6",
        "kpi": "ucii",
        "type": "Line",
        "id": "2446",
        "height": 330
    }
],
      updated: 0
    };
  },
  methods: {
    setType(e, cell) {
       for (let i = 0; i < this.savedCells.length; i++) {
          if(this.savedCells[i].id === cell) {
            this.savedCells[i].type = e.target.value
            console.log(this.savedCells[i])

           }
        }      
    },
    setKpi(e, cell) {
       for (let i = 0; i < this.savedCells.length; i++) {
          if(this.savedCells[i].id === cell) {
             this.savedCells[i].kpi = e.target.value

           }
        }      
    },  
    saveChart(e, cell) {
       for (let i = 0; i < this.savedCells.length; i++) {
          if(this.savedCells[i].id === cell) {
 
             this.savedCells[i].height = this.$refs[cell][0].offsetHeight - 80

           }
        }      
        this.updated++
    },      
    removeSavedCell(cell) {
 
       for (let i = 0; i < this.savedCells.length; i++) {
          if(this.savedCells[i].id === cell) {
              this.$delete(this.savedCells, i)

          }
        }
        console.log(this.savedCells)
    },
    getColStart(i) {
      var pepe = Math.ceil(i % 6);
      if (pepe === 0) {
        pepe = 6;
      }
      return pepe;
    },
    startDrag(e) {
      this.dragging = true;
      this.startX = e.clientX;
      this.startY = e.clientY;

      this.$refs.selecter.style.gridRowStart = e.target.dataset.rowStart;
      this.$refs.selecter.style.gridRowEnd = e.target.dataset.rowEnd;
      this.$refs.selecter.style.gridColumnStart = e.target.dataset.colStart;
      this.$refs.selecter.style.gridColumnEnd = e.target.dataset.colEnd;
      this.$refs.selecter.style.display = "block";
    },
    endDrag(e) {
      this.dragging = false;
      this.startX = "";
      this.startY = "";

      var newCell = {
        rowStart: this.$refs.selecter.style.gridRowStart,
        rowEnd: this.$refs.selecter.style.gridRowEnd,
        colStart: this.$refs.selecter.style.gridColumnStart,
        colEnd: this.$refs.selecter.style.gridColumnEnd,
        kpi: 'emae',
        type: 'Line',
        id: this.$refs.selecter.style.gridRowStart + this.$refs.selecter.style.gridRowEnd + this.$refs.selecter.style.gridColumnStart + this.$refs.selecter.style.gridColumnEnd,

      };
       this.$refs.selecter.style.gridRowStart = ''
      this.$refs.selecter.style.gridRowEnd = ''
      this.$refs.selecter.style.gridColumnStart = ''
      this.$refs.selecter.style.gridColumnEnd =  ''
      this.$refs.selecter.style.display = "none";

      this.savedCells.push(newCell);
    },
    hoverling(e) {
      if (this.dragging === true) {
        var yDir = this.startY - e.clientY;

        var xDir = this.startX - e.clientX;
        if (xDir > 0) {
           this.$refs.selecter.style.gridColumnStart = e.target.dataset.colStart;
        }
        if (xDir < 0) {
           this.$refs.selecter.style.gridColumnEnd = e.target.dataset.colEnd;
        }
        if (yDir > 0) {
           this.$refs.selecter.style.gridRowStart = e.target.dataset.rowStart;
        }
        if (yDir < 0) {
           this.$refs.selecter.style.gridRowEnd = e.target.dataset.rowEnd;
        }
      }
    },
  },
};
</script>

 <style lang="scss">
.container-grid {
  display: grid;
  grid-template-columns: repeat(6, 1fr);
  grid-template-rows: repeat(3, 1fr);
  //height: calc(100vh - 60px);
  position: relative;
  gap: 0px;
  border: 1px dashed #ccc;
  > .singleCell {
    //border: 1px dashed #333;
    border-right: 1px dashed #ccc;
    border-bottom: 1px dashed #ccc;    
    height: 210px;
    cursor: pointer;    
  }
  .selecter-cell {
    position: absolute;
    width: 100%;
    height: 100%;
    background: rgba(255, 255, 0, 0.3);
    display: none;
    pointer-events: none;

  }
  > section {
    background: #fff;
      border: 1px solid #edebe4;
border-radius: 4px;
    position: absolute;
    left: 0;
    bottom: 0;
    top: 0;
    right: 0;
    padding: 20px;
    margin: 5px;
    .chart h2 {
      -webkit-line-clamp: 1;
    -webkit-box-orient: vertical;
    overflow: hidden;
    padding: 0;
    margin-bottom: 20px;
    min-width: 100%;
//height: 20px;
padding-right:20px;
    }
    button.delete {
      background: none;
      border: 0;
      position: absolute;
      right: 10px;
      top: 10px;
      cursor: pointer;
      width: 30px;
      height: 30px;
      z-index: 9;
      svg {
        width: 100%;
        height: auto;
      }
      &:hover svg{
        stroke: #ba000d;
      }
    }
  }
}

.seleccionador {
  position: absolute;
    left: 0;
    bottom: 0;
    top: 0;
    right: 0;
    overflow: auto;
    padding: 15px;
.wrapper {
 label {
   display: block;
 }
}
select {
      margin-bottom: 20px;
      padding: 10px;
      border: 1px solid #ccc;
      width: 100%;
      max-width: 200px;
    }
}
</style>