import Vue from 'vue'
import * as Zoom from 'chartjs-plugin-zoom'

Vue.use(Zoom)

 