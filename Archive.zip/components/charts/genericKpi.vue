<template>
  <section class="chart">
       <h2>
        <strong>{{ chart.t }}</strong>. {{chart.st}}
      </h2>
 
    <h4>{{chart.chartdata.datasets[0].data.slice(-1)[0].toFixed(2)}} </h4>
    <h5 :class="{negative: getCapiVariation(0) < 0}">{{getCapiVariation(0)}}</h5>
  </section>
</template>

<script>
export default {
  props: {
 
    data: {
      type: String,
      required: false,
    },
 
  },
  data() {
    return {
       chart: require(`~/json/confluence/${this.data}.json`)
    };
  },
  created() {
    console.log(this.chart)
  },
  methods: {
    getCapiVariation(i) {
      var A = this.chart.chartdata.datasets[i].data.slice(-1)[0]
      var B = this.chart.chartdata.datasets[i].data.slice(-2)[0]
      return (((A - B) / A) * 100.0).toFixed(2);
 
    },            
  }
};
</script>

 <style lang="scss" scoped>
  h4 {
    font-size: 30px;
    text-align: center;
    margin-bottom: 15px;
    margin-top: 15px;
  }
  h5 {
      font-size: 24px;
      margin-top: 0;
    text-align: center;
          color: green;

    &.negative {
      color: red;
    }
  }
 </style>