module.exports = {
  labels: "",
  datasets: [
    {
      backgroundColor: "rgba(146,220,210,0)",
      label: "Transporte",
      data: "",
      borderColor: "rgba(46,120,210,1)",

      pointRadius: 0,
      borderWidth: 1.5,
    },

  ],
}