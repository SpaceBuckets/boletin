//const colours = cambio.map((value) => value < 0 ? '#b22222CC' : '#009966');
module.exports = {
  labels: require("../reservas/diariadates.json"),
  datasets: [
    {
      backgroundColor: '#ccc',
      label: "Compras Divisas USD",
      data: require("../reservas/diaria.json"),
      barThickness: 0.5,
      pointRadius: 0,
    },
  ],
}

